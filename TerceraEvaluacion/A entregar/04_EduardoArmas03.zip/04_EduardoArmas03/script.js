
var iPre = document.body.firstElementChild.firstElementChild.firstElementChild
function Visualizar(imagen) {
    iPre.src = imagen
}
